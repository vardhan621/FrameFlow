export const sendWhatsApp = (phone, message) => {

  if (!phone) return;

  const mobile = phone.replace(/\D/g, "");

  const url =
    `https://wa.me/91${mobile}?text=${encodeURIComponent(message)}`;

  window.open(url, "_blank");

};