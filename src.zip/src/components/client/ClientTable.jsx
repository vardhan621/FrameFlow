import { useNavigate } from "react-router-dom";

function ClientTable({
  clients,
  loading,
  onEdit,
  onDelete,
}) {
  const navigate = useNavigate();

  return (
    <div className="mt-6 bg-slate-900 rounded-xl border border-slate-800 overflow-hidden">
      <table className="w-full text-left">
        <thead className="bg-slate-800 text-gray-300">
          <tr>
            <th className="p-4 w-72">Client</th>
            <th className="p-4">Shoot</th>
            <th className="p-4">Editing</th>
            <th className="p-4">Album</th>
            <th className="p-4">Delivery</th>
            <th className="p-4">Status</th>
            <th className="p-4">Action</th>
          </tr>
        </thead>

        <tbody>
          {loading ? (
            <tr>
              <td colSpan="7" className="p-4 text-center text-gray-400">
                Loading...
              </td>
            </tr>
          ) : clients.length === 0 ? (
            <tr>
              <td colSpan="7" className="p-4 text-center text-gray-400">
                No Clients Found
              </td>
            </tr>
          ) : (
            clients.map((client) => (
              <tr
                key={client._id}
                className="border-t border-slate-800 hover:bg-slate-800/40"
              >
                {/* Client */}
                <td className="p-4">
                 <div className="space-y-1">
                  <h3 className="text-white text-lg font-bold">
                    {client.clientName}
                  </h3>

                  <p className="text-sm text-gray-400">
                    📞 {client.phone}
                  </p>

                  <p className="text-sm text-gray-400">
                    📅 {new Date(client.eventDate).toLocaleDateString()}
                  </p>

                  <p className="text-sm text-gray-400">
                    🎉 {client.eventType}
                  </p>
                </div>
                </td>

                {/* Shoot */}
                <td className="p-4">
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      client.shootStatus === "Completed"
                      ? "bg-green-500/20 text-green-400"
                      : client.shootStatus === "In Progress"
                      ? "bg-yellow-500/20 text-yellow-400"
                      : client.shootStatus === "Cancelled"
                      ? "bg-red-500/20 text-red-400"
                      : "bg-gray-500/20 text-gray-300"
                    }`}
                  >
                    {client.shootStatus}
                  </span>
                </td>

                {/* Editing */}
                <td className="p-4">
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      client.editingStatus === "Completed"
                        ? "bg-green-500/20 text-green-400"
                        : client.editingStatus === "In Progress"
                        ? "bg-yellow-500/20 text-yellow-400"
                        : "bg-gray-500/20 text-gray-300"
                    }`}
                  >
                    {client.editingStatus}
                  </span>
                </td>

                {/* Album */}
                <td className="p-4">
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      client.albumStatus === "Ready"
                        ? "bg-green-500/20 text-green-400"
                        : client.albumStatus === "Printing"
                        ? "bg-blue-500/20 text-blue-400"
                        : client.albumStatus === "Designing"
                        ? "bg-purple-500/20 text-purple-400"
                        : "bg-gray-500/20 text-gray-300"
                    }`}
                  >
                    {client.albumStatus}
                  </span>
                </td>

                {/* Delivery */}
                <td className="p-4">
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      client.deliveryStatus === "Delivered"
                        ? "bg-green-500/20 text-green-400"
                        : "bg-red-500/20 text-red-400"
                    }`}
                  >
                    {client.deliveryStatus}
                  </span>
                </td>
                <td className="p-4">
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      client.status === "Cancelled"
                        ? "bg-red-500/20 text-red-400"
                        : client.status === "Completed"
                        ? "bg-green-500/20 text-green-400"
                        : "bg-yellow-500/20 text-yellow-400"
                    }`}
                  >
                    {client.status}
                  </span>
                </td>

                {/* Actions */}
                <td className="p-4 whitespace-nowrap">
                  <div className="flex gap-2">

                    <button
                    onClick={() => navigate(`/clients/${client._id}`)}
                    className="px-3 py-1 rounded-lg bg-green-600 hover:bg-green-700 text-white text-sm"
                    >
                    View
                    </button>

                    <button
                    onClick={() => onEdit(client)}
                    className="px-3 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-sm"
                    >
                    Edit
                    </button>

                    <button
                    onClick={() => onDelete(client)}
                    className="px-3 py-1 rounded-lg bg-red-600 hover:bg-red-700 text-white text-sm"
                    >
                    Delete
                    </button>

                    </div>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

export default ClientTable;