import { useState, useEffect } from "react";
import InputField from "../common/InputField";
import LoadingButton from "../common/LoadingButton";
import API from "../../services/api";
import toast from "react-hot-toast";
function ClientForm({ client, onSuccess  }) {
  const [formData, setFormData] = useState({
    clientName: "",
    phone: "",
    email: "",
    address: "",
    eventType: "",
    eventDate: "",
    packageName: "",
    totalAmount: "",
    packageDescription: "",
    firstPayment: "",
    pendingAmount: "",
    notes: "",
  });
  
  useEffect(() => {
    if (client) {
      setFormData({
        clientName: client.clientName || "",
        phone: client.phone || "",
        email: client.email || "",
        address: client.address || "",
        eventType: client.eventType || "",
        eventDate: client.eventDate
          ? client.eventDate.split("T")[0]
          : "",
        packageName: client.packageName || "",
        totalAmount: client.totalAmount || "",
        packageDescription: client.packageDescription || "",
        firstPayment: "",
        pendingAmount: client.pendingAmount || "",
        notes: client.notes || "",

      });
    }
  }, [client]);

  const [loading, setLoading] = useState(false);

  const packageDetails = {
  Basic: {
    price: 15000,
    description: "Photography",
  },
  Gold: {
    price: 35000,
    description: "Photography + Album",
  },
  Premium: {
    price: 60000,
    description: "Photography + Album + Drone + Video",
  },
};

const handleChange = (e) => {
  const { name, value } = e.target;

  if (name === "packageName") {
    const pkg = packageDetails[value];

    setFormData({
      ...formData,
      packageName: value,
      totalAmount: pkg.price,
      packageDescription: pkg.description,
      pendingAmount: pkg.price - Number(formData.firstPayment || 0),
    });

  }  else if (name === "firstPayment") {
  setFormData({
    ...formData,
    firstPayment: parseInt(value),
    pendingAmount: Number(formData.totalAmount) - Number(value),
  });

  } else {
    setFormData({
      ...formData,
      [name]: value,
    });
  }
};
  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log(formData);
    try {
        setLoading(true);

        if (client) {
          await API.put(`/client/${client._id}`, formData);
          toast.success("Client Updated Successfully");
        } else {
          await API.post("/client/add", formData);
          toast.success("Client Added Successfully");
        }
        if (onSuccess) {
          await onSuccess();
        }

    } catch (err) {
        toast.error(err.response?.data?.message || "Failed to add client");
    } finally {
        setLoading(false);
    }
  };
  return (
    <form onSubmit={handleSubmit} className="space-y-4">

      <InputField
        label="Client Name"
        name="clientName"
        type="text"
        value={formData.clientName}
        onChange={handleChange}
        placeholder="Enter Client Name"
      />

      <InputField
        label="Phone Number"
        name="phone"
        type="tel"
        value={formData.phone}
        onChange={handleChange}
        placeholder="Enter Phone Number"
      />
      <InputField
        label="Email"
        name="email"
        type="email"
        value={formData.email}
        onChange={handleChange}
        placeholder="Enter Email"
      />

      <InputField
        label="Address"
        name="address"
        type="text"
        value={formData.address}
        onChange={handleChange}
        placeholder="Enter Address"
      />
      <InputField
        label="Event Type"
        name="eventType"
        type="text"
        value={formData.eventType}
        onChange={handleChange}
        placeholder="Wedding"
      />
      <InputField
        label="Event Date"
        name="eventDate"
        type="date"
        value={formData.eventDate}
        onChange={handleChange}
      />
      <label className="text-white">Package</label>

      <select
        name="packageName"
        value={formData.packageName}
        onChange={handleChange}
        className="w-full p-3 rounded-lg bg-slate-800 border border-slate-700 text-white"
      >
        <option value="">Select Package</option>
        <option value="Basic">Basic</option>
        <option value="Gold">Gold</option>
        <option value="Premium">Premium</option>
      </select>
      <InputField
        label="Total Amount"
        name="totalAmount"
        type="number"
        value={formData.totalAmount}
        readOnly
      />
      <label className="text-white">Package Description</label>

        <textarea
          value={formData.packageDescription}
          readOnly
          rows={3}
          className="w-full p-3 rounded-lg bg-slate-800 border border-slate-700 text-white"
      />
      <InputField
        label="First Payment"
        name="firstPayment"
        type="number"
        value={formData.firstPayment}
        onChange={handleChange}
        placeholder="10000"
      />

      <InputField
        label="Pending Amount"
        name="pendingAmount"
        type="number"
        value={formData.pendingAmount}
        readOnly
      />
      
      <label className="text-white">Notes</label>
        
      <textarea
        name="notes"
        value={formData.notes}
        onChange={handleChange}
        rows={3}
        placeholder="Enter Notes"
        className="w-full p-3 rounded-lg bg-slate-800 border border-slate-700 text-white"
      />
      <LoadingButton
        type="submit"
        loading={loading}
        >
        Save Client
      </LoadingButton>
    </form>
  );
}

export default ClientForm;