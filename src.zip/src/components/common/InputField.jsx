function InputField({
  label,
  type = "text",
  name,
  value,
  onChange,
  placeholder,
  leftIcon,
  rightElement,
  error,
  disabled = false,
  readOnly = false,
  className = "",
}) {
  return (
    <div>
      {label && (
        <label className="block mb-2 text-gray-300">
          {label}
        </label>
      )}

      <div className="relative">
        {leftIcon && (
          <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">
            {leftIcon}
          </div>
        )}

        <input
          type={type}
          inputMode={type === "tel" ? "numeric" : undefined}
          name={name}
          value={value}
          onChange={onChange}
          placeholder={placeholder}
          disabled={disabled}
          className={`w-full rounded-lg border border-slate-700 bg-slate-800 py-3 ${
            leftIcon ? "pl-12" : "pl-4"
          } ${
            rightElement ? "pr-12" : "pr-4"
          } text-white outline-none focus:border-blue-500 disabled:opacity-50 ${className}`}
        />

        {rightElement && (
          <div className="absolute right-3 top-1/2 -translate-y-1/2">
            {rightElement}
          </div>
        )}
      </div>

      {error && (
        <p className="mt-1 text-sm text-red-500">
          {error}
        </p>
      )}
    </div>
  );
}

export default InputField;