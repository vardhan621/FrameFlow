function LoadingButton({ loading, children }) {
  return (
    <button
      type="submit"
      disabled={loading}
      className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 disabled:opacity-50 text-white p-3 rounded-lg font-semibold transition-all duration-300"
    >
      {loading ? "⏳ Logging in..." : children}
    </button>
  );
}

export default LoadingButton;