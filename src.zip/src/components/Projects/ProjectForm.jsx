import { useEffect, useState } from "react";
import API from "../../services/api";

const projectTypes = [
  "Wedding",
  "Pre Wedding",
  "Birthday",
  "Reception",
  "Engagement",
  "Maternity",
  "Baby Shoot",
  "Corporate",
  "Other",
];

const projectStatus = [
  "New Booking",
  "Shoot Scheduled",
  "Shoot Completed",
  "Editing",
  "Client Selection",
  "Album Designing",
  "Printing",
  "Ready For Delivery",
  "Delivered",
  "Completed",
];

function ProjectForm({ onSubmit, initialData = {}, loading = false }) {
  const [clients, setClients] = useState([]);

  const [formData, setFormData] = useState({
    client: initialData.client?._id || "",
    projectName: initialData.projectName || "",
    projectType: initialData.projectType || "",
    shootDate: initialData.shootDate?.substring(0, 10) || "",
    deliveryDate: initialData.deliveryDate?.substring(0, 10) || "",
    status: initialData.status || "New Booking",
    notes: initialData.notes || "",
  });

  useEffect(() => {
    fetchClients();
  }, []);

  const fetchClients = async () => {
  try {
    const token = localStorage.getItem("token");
    console.log("TOKEN:", token);

    const res = await API.get("/client");

    console.log("CLIENT RESPONSE:", res.data);

    setClients(res.data.clients || []);
  } catch (err) {
    console.log("CLIENT ERROR:", err.response?.data);
  }
};

  const handleChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-white rounded-xl shadow-md p-6 space-y-5"
    >
      <h2 className="text-xl font-bold">
        {initialData._id ? "Edit Project" : "Add Project"}
      </h2>

      <div>
        <label className="block mb-1 font-medium">
          Client
        </label>

        <select
          name="client"
          value={formData.client}
          onChange={handleChange}
          className="w-full border rounded-lg p-2"
          required
        >
          <option value="">Select Client</option>

          {clients.map((client) => (
            <option
              key={client._id}
              value={client._id}
            >
              {client.clientName}
            </option>
          ))}
        </select>
      </div>

      <div>
        <label className="block mb-1 font-medium">
          Project Name
        </label>

        <input
          type="text"
          name="projectName"
          value={formData.projectName}
          onChange={handleChange}
          className="w-full border rounded-lg p-2"
          required
        />
      </div>

      <div>
        <label className="block mb-1 font-medium">
          Project Type
        </label>

        <select
          name="projectType"
          value={formData.projectType}
          onChange={handleChange}
          className="w-full border rounded-lg p-2"
          required
        >
          <option value="">Select Type</option>

          {projectTypes.map((type) => (
            <option key={type} value={type}>
              {type}
            </option>
          ))}
        </select>
      </div>

      <div className="grid md:grid-cols-2 gap-4">

        <div>
          <label className="block mb-1 font-medium">
            Shoot Date
          </label>

          <input
            type="date"
            name="shootDate"
            value={formData.shootDate}
            onChange={handleChange}
            className="w-full border rounded-lg p-2"
          />
        </div>

        <div>
          <label className="block mb-1 font-medium">
            Delivery Date
          </label>

          <input
            type="date"
            name="deliveryDate"
            value={formData.deliveryDate}
            onChange={handleChange}
            className="w-full border rounded-lg p-2"
          />
        </div>

      </div>

      <div>
        <label className="block mb-1 font-medium">
          Status
        </label>

        <select
          name="status"
          value={formData.status}
          onChange={handleChange}
          className="w-full border rounded-lg p-2"
        >
          {projectStatus.map((status) => (
            <option key={status} value={status}>
              {status}
            </option>
          ))}
        </select>
      </div>

      <div>
        <label className="block mb-1 font-medium">
          Notes
        </label>

        <textarea
          rows="4"
          name="notes"
          value={formData.notes}
          onChange={handleChange}
          className="w-full border rounded-lg p-2"
        />
      </div>

      <button
        type="submit"
        disabled={loading}
        className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
      >
        {loading ? "Saving..." : "Save Project"}
      </button>
    </form>
  );
}

export default ProjectForm;