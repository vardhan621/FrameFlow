import {
  FaSearch,
  FaThLarge,
  FaList,
} from "react-icons/fa";

export default function Toolbar({
  search,
  setSearch,
  viewMode,
  setViewMode,
  sortBy,
  setSortBy,
}) {
  return (
    <div className="bg-white rounded-2xl shadow-lg p-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4">

      {/* Search Box */}
      <div className="relative flex-1">

        <FaSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />

        <input
          type="text"
          placeholder="Search files..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full border rounded-xl pl-12 pr-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />

      </div>

      {/* Right Side */}
      <div className="flex items-center gap-3">

        {/* Sort */}
        <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="border rounded-xl px-3 py-2"
        >
            <option value="newest">Newest First</option>
            <option value="oldest">Oldest First</option>
            <option value="nameAsc">Name (A-Z)</option>
            <option value="nameDesc">Name (Z-A)</option>
            <option value="sizeLarge">Largest Size</option>
            <option value="sizeSmall">Smallest Size</option>
        </select>

        {/* Grid View */}
        <button
          onClick={() => setViewMode("grid")}
          className={`p-3 rounded-xl transition ${
            viewMode === "grid"
              ? "bg-blue-600 text-white"
              : "bg-gray-100 hover:bg-gray-200"
          }`}
        >
          <FaThLarge />
        </button>

        {/* List View */}
        <button
          onClick={() => setViewMode("list")}
          className={`p-3 rounded-xl transition ${
            viewMode === "list"
              ? "bg-blue-600 text-white"
              : "bg-gray-100 hover:bg-gray-200"
          }`}
        >
          <FaList />
        </button>

      </div>

    </div>
  );
}