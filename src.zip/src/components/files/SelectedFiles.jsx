import { FaFileAlt, FaTimes } from "react-icons/fa";

export default function SelectedFiles({
  selectedFiles,
  setSelectedFiles,
}) {
  if (!selectedFiles || selectedFiles.length === 0) return null;

  const removeFile = (index) => {
    const files = Array.from(selectedFiles);
    files.splice(index, 1);

    const dt = new DataTransfer();

    files.forEach(file => dt.items.add(file));

    setSelectedFiles(dt.files);
  };

  return (
    <div className="mt-6">

      <h3 className="font-semibold mb-3">
        Selected Files ({selectedFiles.length})
      </h3>

      <div className="space-y-2">

        {Array.from(selectedFiles).map((file,index)=>(
          <div
            key={index}
            className="flex justify-between items-center bg-slate-100 rounded-xl px-4 py-3"
          >

            <div className="flex items-center gap-3">

              <FaFileAlt className="text-blue-600"/>

              <div>

                <p className="font-medium">
                  {file.name}
                </p>

                <p className="text-xs text-gray-500">
                  {(file.size/1024/1024).toFixed(2)} MB
                </p>

              </div>

            </div>

            <button
              onClick={()=>removeFile(index)}
              className="text-red-500 hover:text-red-700"
            >
              <FaTimes/>
            </button>

          </div>
        ))}

      </div>

    </div>
  );
}