import { useEffect, useState } from "react";
import API from "../../services/api";
import InputField from "../common/InputField";
import LoadingButton from "../common/LoadingButton";
import toast from "react-hot-toast";

function EmployeeForm({ employee, onSuccess }) {
  const [loading, setLoading] = useState(false);

  const [formData, setFormData] = useState({
    name: "",
    role: "Photographer",
    phone: "",
    email: "",
    salary: "",
    status: "Active",
    username: "",
    password: "",
  });
  useEffect(() => {
    if (employee) {
      setFormData({
        name: employee.name || "",
        role: employee.role || "Photographer",
        phone: employee.phone || "",
        email: employee.email || "",
        salary: employee.salary || "",
        status: employee.status || "Active",
        username: employee.username || "",
        password: "",
      });
    }
  }, [employee]);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

        try {
        setLoading(true);

        const data = { ...formData };

        if (employee && !data.password) {
          delete data.password;
        }

        if (employee) {
          await API.put(`/employee/${employee._id}`, data);
          toast.success("Employee Updated Successfully");
        } else {
          await API.post("/employee/add", data);
          toast.success("Employee Added Successfully");
        }

            
        console.log("onSuccess =", onSuccess);

        if (typeof onSuccess === "function") {
            await onSuccess();
        } else {
            console.error("onSuccess is not a function");
        }

        } catch (error) {
        console.log(error);
        toast.error(error.response?.data?.message || "Failed to save employee");
        } finally {
        setLoading(false);
        }
    };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">

      <InputField
        label="Employee Name"
        name="name"
        value={formData.name}
        onChange={handleChange}
      />

      <label className="text-white">
        Role
      </label>

      <select
        name="role"
        value={formData.role}
        onChange={handleChange}
        className="w-full p-3 rounded-lg bg-slate-800 border border-slate-700 text-white"
      >
        <option>Photographer</option>
        <option>Videographer</option>
        <option>Editor</option>
        <option>Drone Operator</option>
        <option>Album Designer</option>
        <option>Assistant</option>
      </select>

      <InputField
        label="Phone"
        name="phone"
        value={formData.phone}
        onChange={handleChange}
      />

      <InputField
        label="Email"
        name="email"
        value={formData.email}
        onChange={handleChange}
      />
      <InputField
        label="Username"
        name="username"
        value={formData.username}
        onChange={handleChange}
      />

      <InputField
        label="Password"
        type="password"
        name="password"
        value={formData.password}
        onChange={handleChange}
      />
      <InputField
        label="Salary"
        type="number"
        name="salary"
        value={formData.salary}
        onChange={handleChange}
      />

      <label className="text-white">
        Status
      </label>

      <select
        name="status"
        value={formData.status}
        onChange={handleChange}
        className="w-full p-3 rounded-lg bg-slate-800 border border-slate-700 text-white"
      >
        <option>Active</option>
        <option>Inactive</option>
      </select>

      <LoadingButton
        loading={loading}
        type="submit"
      >
        {employee ? "Update Employee" : "Add Employee"}
      </LoadingButton>

    </form>
  );
}

export default EmployeeForm;