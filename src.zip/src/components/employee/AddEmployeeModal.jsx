import EmployeeForm from "./EmployeeForm";

function AddEmployeeModal({ employee, onClose, onSuccess }) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60"
      onClick={onClose}
    >
      <div
        className="bg-slate-900 w-full max-w-xl rounded-xl border border-slate-800 p-6 max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-white">
            {employee ? "Edit Employee" : "Add Employee"}
          </h2>

          <button
            type="button"
            onClick={onClose}
            className="text-white text-2xl"
          >
            ✕
          </button>
        </div>

        <EmployeeForm
          employee={employee}
          onSuccess={onSuccess}
        />
      </div>
    </div>
  );
}

export default AddEmployeeModal;