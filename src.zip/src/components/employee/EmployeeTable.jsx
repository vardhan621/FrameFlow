function EmployeeTable({
  employees,
  loading,
  onEdit,
  onDelete,
}) {
  return (
    <div className="mt-6 bg-slate-900 rounded-xl border border-slate-800 overflow-hidden">
      <table className="w-full text-left">

        <thead className="bg-slate-800 text-gray-300">
          <tr>
            <th className="p-4">Name</th>
            <th className="p-4">Role</th>
            <th className="p-4">Phone</th>
            <th className="p-4">Salary</th>
            <th className="p-4">Status</th>
            <th className="p-4">Action</th>
          </tr>
        </thead>

        <tbody>

          {loading ? (
            <tr>
              <td
                colSpan="6"
                className="text-center p-6 text-gray-400"
              >
                Loading...
              </td>
            </tr>

          ) : employees.length === 0 ? (

            <tr>
              <td
                colSpan="6"
                className="text-center p-6 text-gray-400"
              >
                No Employees Found
              </td>
            </tr>

          ) : (

            employees.map((employee) => (

              <tr
                key={employee._id}
                className="border-t border-slate-800"
              >

                <td className="p-4 text-white">
                  {employee.name}
                </td>

                <td className="p-4 text-gray-300">
                  {employee.role}
                </td>

                <td className="p-4 text-gray-300">
                  {employee.phone}
                </td>

                <td className="p-4 text-green-400">
                  ₹{employee.salary}
                </td>

                <td className="p-4">
                  <span
                    className={`px-3 py-1 rounded-full text-white text-sm ${
                      employee.status === "Active"
                        ? "bg-green-600"
                        : "bg-red-600"
                    }`}
                  >
                    {employee.status}
                  </span>
                </td>

                <td className="p-4">

                  <button
                    onClick={() => onEdit(employee)}
                    className="text-blue-500 hover:underline mr-4"
                  >
                    Edit
                  </button>

                  <button
                    onClick={() => onDelete(employee)}
                    className="text-red-500 hover:underline"
                  >
                    Delete
                  </button>

                </td>

              </tr>

            ))

          )}

        </tbody>

      </table>
    </div>
  );
}

export default EmployeeTable;