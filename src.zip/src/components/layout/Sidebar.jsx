import { useEffect, useState } from "react";
import {
  FiHome,
  FiUsers,
  FiCamera,
  FiDollarSign,
  FiSettings,
  FiCalendar,
  FiUser,
  FiImage,
  FiCreditCard,
  FiBarChart2,
  FiClock,
  FiClipboard,
  FiFolder,
} from "react-icons/fi";

import { NavLink } from "react-router-dom";
import API from "../../services/api";

function Sidebar() {
  const [studio, setStudio] = useState(null);

  useEffect(() => {
    fetchStudio();
  }, []);

  const fetchStudio = async () => {
    try {
      const res = await API.get("/settings");
      setStudio(res.data.studio);
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <aside className="w-64 bg-slate-900 border-r border-slate-800 min-h-screen">

      {/* Logo */}

      <div className="p-6 border-b border-slate-800 flex flex-col items-center">

        {studio?.logo ? (

          <img
            src={studio.logo}
            alt="Studio Logo"
            className="w-24 h-24 rounded-full bg-white object-contain p-2 shadow-lg"
          />

        ) : (

          <div className="w-24 h-24 rounded-full bg-slate-800 flex justify-center items-center text-5xl">
            📸
          </div>

        )}

        <h1 className="text-xl font-bold text-white mt-4 text-center">
          {studio?.studioName || "FrameFlow Studio"}
        </h1>

        <p className="text-sm text-gray-400">
          {studio?.ownerName || "Studio Owner"}
        </p>

      </div>

      {/* Menu */}

      <nav className="p-4 space-y-2">

        <NavLink
          to="/dashboard"
          className={({ isActive }) =>
            `flex items-center gap-3 p-3 rounded-lg ${
              isActive
                ? "bg-blue-600 text-white"
                : "text-gray-300 hover:bg-slate-800"
            }`
          }
        >
          <FiHome />
          Dashboard
        </NavLink>

        <NavLink
          to="/clients"
          className={({ isActive }) =>
            `flex items-center gap-3 p-3 rounded-lg ${
              isActive
                ? "bg-blue-600 text-white"
                : "text-gray-300 hover:bg-slate-800"
            }`
          }
        >
          <FiUsers />
          Clients
        </NavLink>

        <NavLink
          to="/calendar"
          className={({ isActive }) =>
            `flex items-center gap-3 p-3 rounded-lg ${
              isActive
                ? "bg-blue-600 text-white"
                : "text-gray-300 hover:bg-slate-800"
            }`
          }
        >
          <FiCalendar />
          Calendar
        </NavLink>

        <NavLink
          to="/shoots"
          className={({ isActive }) =>
            `flex items-center gap-3 p-3 rounded-lg ${
              isActive
                ? "bg-blue-600 text-white"
                : "text-gray-300 hover:bg-slate-800"
            }`
          }
        >
          <FiCamera />
          Shoots
        </NavLink>

        <NavLink
          to="/payments"
          className={({ isActive }) =>
            `flex items-center gap-3 p-3 rounded-lg ${
              isActive
                ? "bg-blue-600 text-white"
                : "text-gray-300 hover:bg-slate-800"
            }`
          }
        >
          <FiDollarSign />
          Payments
        </NavLink>
        <NavLink
          to="/expenses"
          className={({ isActive }) =>
            `flex items-center gap-3 p-3 rounded-lg ${
              isActive
                ? "bg-blue-600 text-white"
                : "text-gray-300 hover:bg-slate-800"
            }`
          }
        >
          <FiCreditCard />
          Expenses
        </NavLink>
        <NavLink
          to="/gallery"
          className={({ isActive }) =>
            `flex items-center gap-3 p-3 rounded-lg ${
              isActive
                ? "bg-blue-600 text-white"
                : "text-gray-300 hover:bg-slate-800"
            }`
          }
        >
          <FiImage />
          Gallery
        </NavLink>

        <NavLink
          to="/employees"
          className={({ isActive }) =>
            `flex items-center gap-3 p-3 rounded-lg ${
              isActive
                ? "bg-blue-600 text-white"
                : "text-gray-300 hover:bg-slate-800"
            }`
          }
        >
          <FiUser />
          Employees
        </NavLink>
        <NavLink
          to="/attendance"
          className={({ isActive }) =>
            `flex items-center gap-3 p-3 rounded-lg ${
              isActive
                ? "bg-blue-600 text-white"
                : "text-gray-300 hover:bg-slate-800"
            }`
          }
        >
          <FiClock />
          Attendance
        </NavLink>
        <NavLink
          to="/leave"
          className={({ isActive }) =>
            `flex items-center gap-3 p-3 rounded-lg ${
              isActive
                ? "bg-blue-600 text-white"
                : "text-gray-300 hover:bg-slate-800"
            }`
          }
        >
          <FiClipboard />
          Leave
        </NavLink>
        <NavLink
          to="/reports"
          className={({ isActive }) =>
            `flex items-center gap-3 p-3 rounded-lg ${
              isActive
                ? "bg-blue-600 text-white"
                : "text-gray-300 hover:bg-slate-800"
            }`
          }
        >
          <FiBarChart2 />
          Reports
        </NavLink>
        <NavLink
          to="/settings"
          className={({ isActive }) =>
            `flex items-center gap-3 p-3 rounded-lg ${
              isActive
                ? "bg-blue-600 text-white"
                : "text-gray-300 hover:bg-slate-800"
            }`
          }
        >
          <FiSettings />
          Settings
        </NavLink>
        <NavLink
          to="/tasks"
          className={({ isActive }) =>
            `flex items-center gap-3 p-3 rounded-lg ${
              isActive
                ? "bg-blue-600 text-white"
                : "text-gray-300 hover:bg-slate-800"
            }`
          }
        >
          <FiClipboard />
          Tasks
        </NavLink>
        <NavLink
          to="/projects"
          className={({ isActive }) =>
            `flex items-center gap-3 p-3 rounded-lg ${
              isActive
                ? "bg-blue-600 text-white"
                : "text-gray-300 hover:bg-slate-800"
            }`
          }
        >
          <FiFolder />
          Projects
        </NavLink>
      </nav>

    </aside>
  );
}

export default Sidebar;