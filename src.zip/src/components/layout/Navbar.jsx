import { FiLogOut, FiBell } from "react-icons/fi";
import NotificationBell from "./NotificationBell";
import { useNavigate } from "react-router-dom";
import SearchBar from "./SearchBar";
function Navbar() {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  return (
    <header className="h-16 bg-slate-900 border-b border-slate-800 flex items-center justify-between px-6">

      <h2 className="text-xl font-semibold text-white">
        Dashboard
      </h2>

      <div className="flex items-center gap-5 relative z-[9999]">

        <SearchBar />

        <NotificationBell />

        <button
          onClick={handleLogout}
          className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg"
        >
          <FiLogOut />
          Logout
        </button>

      </div>

    </header>
  );
}

export default Navbar;