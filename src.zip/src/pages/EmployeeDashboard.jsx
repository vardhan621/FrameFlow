import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { FaBell, FaTrash } from "react-icons/fa";
import EmployeeAPI from "../services/employeeApi";
import toast from "react-hot-toast";
import ApplyLeaveModal from "../components/employee/ApplyLeaveModal";
import socket from "../socket";
function EmployeeDashboard() {
  const navigate = useNavigate();

  const [employee, setEmployee] = useState(null);
  const [loading, setLoading] = useState(true);

  const [todayShoots, setTodayShoots] = useState([]);
  const [upcomingShoots, setUpcomingShoots] = useState([]);

  const [completed, setCompleted] = useState(0);
  const [pending, setPending] = useState(0);

  const [showLeave, setShowLeave] = useState(false);

  // Notification States
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [showNotifications, setShowNotifications] = useState(false);

  useEffect(() => {
    const data = JSON.parse(localStorage.getItem("employee"));

    if (!data) {
      navigate("/employee/login");
      return;
    }

    setEmployee(data);
    console.log("Joining Employee Room:", data._id);

    socket.emit("joinEmployee", data._id);
    fetchDashboard();
    fetchNotifications();
  }, [navigate]);
  useEffect(() => {
  const data = JSON.parse(localStorage.getItem("employee"));

  if (!data) {
    navigate("/employee/login");
    return;
  }

  setEmployee(data);

  socket.on("connect", () => {
    console.log("✅ Socket Connected:", socket.id);

    console.log("Joining Employee Room:", data._id);

    socket.emit("joinEmployee", data._id);
  });

  socket.on("newNotification", (notification) => {
    console.log("🔔 Notification Received", notification);

    fetchNotifications();

    const audio = new Audio("/notification.wav");

    audio.volume = 1;

    audio.play()
      .then(() => console.log("✅ Sound Played"))
      .catch((err) => console.log("❌ Audio Error:", err));
  });

  fetchDashboard();
  fetchNotifications();

  return () => {
    socket.off("connect");
    socket.off("newNotification");
  };

}, [navigate]);
  // ================= Dashboard =================

  const fetchDashboard = async () => {
    try {
      const res = await EmployeeAPI.get("/employee/dashboard");

      setTodayShoots(res.data.todayShoots || []);
      setUpcomingShoots(res.data.upcomingShoots || []);
      setCompleted(res.data.completed || 0);
      setPending(res.data.pending || 0);

    } catch (err) {
      console.log(err);
      toast.error("Failed to load dashboard");
    } finally {
      setLoading(false);
    }
  };

  // ================= Notifications =================

  const fetchNotifications = async () => {
    try {

      const res = await EmployeeAPI.get("/notification/employee");

      setNotifications(res.data.notifications || []);
      setUnreadCount(res.data.unreadCount || 0);

    } catch (err) {
      console.log(err);
    }
  };

  const markAllRead = async () => {
    try {

      await EmployeeAPI.put("/notification/employee/read-all");

      fetchNotifications();

    } catch (err) {
      console.log(err);
    }
  };

  const clearAllNotifications = async () => {
    try {

      await EmployeeAPI.delete("/notification/employee/clear");

      fetchNotifications();

    } catch (err) {
      console.log(err);
    }
  };

  const deleteNotification = async (id) => {
    try {

      await EmployeeAPI.delete(`/notification/employee/${id}`);

      fetchNotifications();

    } catch (err) {
      console.log(err);
    }
  };

  const handleNotificationClick = async (item) => {

    try {

      if (!item.isRead) {
        await EmployeeAPI.put(
          `/notification/employee/${item._id}/read`
        );
      }

      fetchNotifications();

      setShowNotifications(false);

      switch (item.type) {

        case "task":
          navigate("/employee/tasks");
          return;

        case "leave":
          navigate("/employee/leaves");
          return;

        default:
          navigate("/employee/dashboard");
      }

    } catch (err) {
      console.log(err);
    }
  };

  // ================= Shoot Status =================

  const updateShootStatus = async (clientId, status) => {
    try {

      await EmployeeAPI.put(`/client/${clientId}`, {
        shootStatus: status,
      });

      toast.success("Status Updated");

      fetchDashboard();

    } catch (err) {
      console.log(err);
      toast.error("Update Failed");
    }
  };

  // ================= Logout =================

  const logout = () => {
    localStorage.removeItem("employee");
    localStorage.removeItem("employeeToken");

    navigate("/employee/login");
  };

  if (!employee || loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center text-white text-2xl">
        Loading...
      </div>
    );
  }
  return (
  <div className="min-h-screen bg-slate-950 p-8">

    {/* Header */}

    <div className="flex justify-between items-center mb-8">

      <div>

        <h1 className="text-3xl font-bold text-white">
          Welcome {employee.name}
        </h1>

        <p className="text-gray-400 mt-2">
          {employee.role}
        </p>

      </div>

      <div className="flex items-center gap-4 relative">

        {/* Notification Bell */}

        <button
          onClick={() =>
            setShowNotifications(!showNotifications)
          }
          className="relative text-white text-2xl"
        >
          <FaBell />

          {unreadCount > 0 && (
            <span className="absolute -top-2 -right-2 bg-red-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
              {unreadCount}
            </span>
          )}

        </button>

        {/* Notification Popup */}

        {showNotifications && (

          <div className="absolute top-14 right-0 w-96 bg-slate-900 rounded-xl shadow-xl border border-slate-700 z-50">

            {/* Header */}

            <div className="flex justify-between items-center p-4 border-b border-slate-700">

              <h2 className="text-white font-bold">
                Notifications
              </h2>

              <div className="flex gap-3">

                <button
                  onClick={markAllRead}
                  className="text-blue-400 text-sm"
                >
                  Mark All
                </button>

                <button
                  onClick={clearAllNotifications}
                  className="text-red-400 text-sm"
                >
                  Clear
                </button>

              </div>

            </div>

            {/* Notifications */}

            <div className="max-h-96 overflow-y-auto">

              {notifications.length === 0 ? (

                <div className="p-5 text-center text-gray-400">
                  No Notifications
                </div>

              ) : (

                notifications.map((item) => (

                  <div
                    key={item._id}
                    onClick={() =>
                      handleNotificationClick(item)
                    }
                    className={`cursor-pointer border-b border-slate-800 p-4 hover:bg-slate-800 transition ${
                      item.isRead
                        ? ""
                        : "bg-slate-800"
                    }`}
                  >

                    <div className="flex justify-between items-start">

                      <div>

                        <div className="flex items-center gap-2">

                          {!item.isRead && (
                            <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                          )}

                          <h3 className="text-white font-semibold">
                            {item.title}
                          </h3>

                        </div>

                        <p className="text-gray-400 text-sm mt-1">
                          {item.message}
                        </p>

                      </div>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteNotification(item._id);
                        }}
                        className="text-red-500 hover:text-red-400"
                      >
                        <FaTrash />
                      </button>

                    </div>

                  </div>

                ))

              )}

            </div>

          </div>

        )}

        {/* Leave */}

        <button
          onClick={() => setShowLeave(true)}
          className="bg-yellow-600 hover:bg-yellow-700 px-5 py-2 rounded-lg text-white"
        >
          Apply Leave
        </button>

        {/* Logout */}

        <button
          onClick={logout}
          className="bg-red-600 hover:bg-red-700 px-5 py-2 rounded-lg text-white"
        >
          Logout
        </button>

      </div>

    </div>

    {/* Stats */}

    <div className="grid md:grid-cols-3 gap-6">

      <div className="bg-slate-900 rounded-xl p-6">

        <h2 className="text-xl text-white font-bold">
          Assigned Clients
        </h2>

        <p className="text-4xl text-blue-400 mt-4">
          {todayShoots.length + upcomingShoots.length}
        </p>

      </div>

      <div className="bg-slate-900 rounded-xl p-6">

        <h2 className="text-xl text-white font-bold">
          Pending Work
        </h2>

        <p className="text-4xl text-yellow-400 mt-4">
          {pending}
        </p>

      </div>

      <div className="bg-slate-900 rounded-xl p-6">

        <h2 className="text-xl text-white font-bold">
          Completed
        </h2>

        <p className="text-4xl text-green-400 mt-4">
          {completed}
        </p>

      </div>

    </div>

    {/* Today's Shoots */}
          {/* Apply Leave Modal */}

      {showLeave && (
        <ApplyLeaveModal
          employeeId={employee._id}
          onClose={() => setShowLeave(false)}
          onSuccess={() => {
            setShowLeave(false);
            toast.success("Leave Applied");
            fetchNotifications();
          }}
        />
      )}

    </div>
  );
}

export default EmployeeDashboard;


