import Layout from "../components/layout/Layout";
import { useEffect, useState } from "react";
import {
  useLocation,
  useNavigate,
} from "react-router-dom";
import API from "../services/api";
import AddEmployeeModal from "../components/employee/AddEmployeeModal";
import EmployeeTable from "../components/employee/EmployeeTable";
import toast from "react-hot-toast";

function Employees() {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [search, setSearch] = useState("");
  const location = useLocation();
  const navigate = useNavigate();
  useEffect(() => {
    const params = new URLSearchParams(location.search);

    if (params.get("new") === "true") {
      setShowModal(true);
    }
  }, [location]);
  useEffect(() => {
    fetchEmployees();
  }, []);

  const fetchEmployees = async () => {
    setLoading(true);

    try {
      const res = await API.get("/employee");
      setEmployees(res.data.employees);
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (employee) => {
    if (!window.confirm(`Delete ${employee.name}?`)) return;

    try {
      await API.delete(`/employee/${employee._id}`);

      toast.success("Employee Deleted Successfully");

      fetchEmployees();
    } catch (error) {
      toast.error("Failed to delete employee");
    }
  };

  return (
    <Layout>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-white">
          Employees
        </h1>

        <button
          onClick={() => setShowModal(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg"
        >
          + Add Employee
        </button>
      </div>

      <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
        <input
          type="text"
          placeholder="Search Employee..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full p-3 rounded-lg bg-slate-800 border border-slate-700 text-white outline-none"
        />
      </div>

      <EmployeeTable
        employees={employees.filter((employee) =>
          employee.name
            .toLowerCase()
            .includes(search.toLowerCase())
        )}
        loading={loading}
        onEdit={(employee) => {
          setSelectedEmployee(employee);
          setShowModal(true);
        }}
        onDelete={handleDelete}
      />

      {showModal && (
        <AddEmployeeModal
          employee={selectedEmployee}
          onClose={() => {
            setShowModal(false);
            setSelectedEmployee(null);
          }}
          onSuccess={async () => {

            await fetchEmployees();

            setShowModal(false);

            setSelectedEmployee(null);

            if (location.search.includes("new=true")) {
              navigate("/dashboard");
            }

          }}
        />
      )}
    </Layout>
  );
}

export default Employees;