import { useState } from "react";
import { useNavigate } from "react-router-dom";
import ProjectForm from "../components/Projects/ProjectForm";
import { createProject } from "../services/projectService";

function AddProject() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const handleCreate = async (formData) => {
    try {
      setLoading(true);

      await createProject(formData);

      alert("Project created successfully");

      navigate("/projects");
    } catch (error) {
      console.error(error);

      alert(
        error?.response?.data?.message ||
          "Failed to create project"
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6">
      <ProjectForm
        onSubmit={handleCreate}
        loading={loading}
      />
    </div>
  );
}

export default AddProject;