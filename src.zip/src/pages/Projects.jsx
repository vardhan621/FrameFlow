import React, { useEffect, useState } from "react";
import { getProjects } from "../services/projectService";
import { Link } from "react-router-dom";
import { FiPlus } from "react-icons/fi";

const Projects = () => {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProjects();
  }, []);

  const fetchProjects = async () => {
    try {
      const res = await getProjects();
      setProjects(res.data.projects || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6">

      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-800">
          Projects
        </h1>

        <Link
          to="/projects/new"
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition"
        >
          <FiPlus />
          New Project
        </Link>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl shadow overflow-hidden">

        <table className="w-full">

          <thead className="bg-gray-100">
            <tr>
              <th className="text-left px-5 py-3">Project</th>
              <th className="text-left px-5 py-3">Client</th>
              <th className="text-left px-5 py-3">Status</th>
              <th className="text-left px-5 py-3">Shoot Date</th>
              <th className="text-left px-5 py-3">Payment</th>
            </tr>
          </thead>

          <tbody>

            {loading ? (
              <tr>
                <td
                  colSpan="5"
                  className="text-center py-8 text-gray-500"
                >
                  Loading Projects...
                </td>
              </tr>
            ) : projects.length === 0 ? (
              <tr>
                <td
                  colSpan="5"
                  className="text-center py-8 text-gray-500"
                >
                  No Projects Found
                </td>
              </tr>
            ) : (
              projects.map((project) => (
                <tr
                  key={project._id}
                  className="border-t hover:bg-gray-50"
                >
                  <td className="px-5 py-3 font-medium">
                    <Link
                        to={`/projects/${project._id}`}
                        className="text-blue-600 hover:underline"
                    >
                        {project.projectName}
                    </Link>
                  </td>

                  <td className="px-5 py-3">
                    {project.client?.clientName || "-"}
                  </td>

                  <td className="px-5 py-3">
                    <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm">
                      {project.status}
                    </span>
                  </td>

                  <td className="px-5 py-3">
                    {project.shootDate
                      ? new Date(project.shootDate).toLocaleDateString()
                      : "-"}
                  </td>

                  <td className="px-5 py-3">
                    {project.paymentStatus || "Pending"}
                  </td>
                </tr>
              ))
            )}

          </tbody>

        </table>

      </div>

    </div>
  );
};

export default Projects;