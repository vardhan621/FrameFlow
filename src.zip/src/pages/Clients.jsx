import Layout from "../components/layout/Layout";
import { useEffect, useState } from "react";
import {
  useLocation,
  useNavigate,
} from "react-router-dom";
import API from "../services/api";
import AddClientModal from "../components/client/AddClientModal";
import ClientTable from "../components/client/ClientTable";
import toast from "react-hot-toast";

function Clients() {
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [selectedClient, setSelectedClient] = useState(null);
  const [search, setSearch] = useState("");
  const [eventFilter, setEventFilter] = useState("All");
  const [summary, setSummary] = useState({
    totalClients: 0,
    pendingAmount: 0,
    pendingShoot: 0,
    pendingDelivery: 0,
  });
  const [eventTypes, setEventTypes] = useState(["All"]);
  const [filter, setFilter] = useState("All");
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [limit, setLimit] = useState(10);
  const location = useLocation();
  const navigate = useNavigate();
  useEffect(() => {
    const params = new URLSearchParams(location.search);

    if (params.get("new") === "true") {
      setShowModal(true);
    }
  }, [location]);
  useEffect(() => {
    fetchClients();
  }, [page, limit, search, eventFilter, filter]);

  const fetchClients = async () => {
    setLoading(true);

    try {
      const res = await API.get(
        `/client?page=${page}&limit=${limit}&search=${encodeURIComponent(search)}&eventType=${encodeURIComponent(eventFilter)}&status=${encodeURIComponent(filter)}`
      );

      const clientData = res.data.clients;

      setClients(clientData);
      setTotalPages(res.data.totalPages);
      setEventTypes([
        "All",
        ...res.data.eventTypes,
      ]);
      setSummary({
        totalClients: res.data.totalClients,

        pendingAmount: clientData.reduce(
          (sum, c) => sum + Number(c.pendingAmount || 0),
          0
        ),

        pendingShoot: clientData.filter(
          (c) => c.shootStatus !== "Completed"
        ).length,

        pendingDelivery: clientData.filter(
          (c) => c.deliveryStatus !== "Delivered"
        ).length,
      });

    } catch (err) {
      console.log(err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (client) => {
    if (!window.confirm(`Delete ${client.clientName}?`)) return;

    try {
      await API.delete(`/client/${client._id}`);

      toast.success("Client Deleted Successfully");

      fetchClients();

    } catch (err) {
      toast.error("Failed to delete client");
    }
  };

  return (
    <Layout>

      <div className="flex justify-between items-center mb-6">

        <h1 className="text-3xl font-bold text-white">
          Clients
        </h1>

        <button
          onClick={() => setShowModal(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg"
        >
          + Add Client
        </button>

      </div>

      {/* Summary Cards */}

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-5 mb-6">

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">

          <p className="text-gray-400">
            Total Clients
          </p>

          <h2 className="text-3xl font-bold text-blue-400 mt-2">
            {summary.totalClients}
          </h2>

        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">

          <p className="text-gray-400">
            Pending Amount
          </p>

          <h2 className="text-3xl font-bold text-yellow-400 mt-2">
            ₹{summary.pendingAmount.toLocaleString()}
          </h2>

        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">

          <p className="text-gray-400">
            Shoots Pending
          </p>

          <h2 className="text-3xl font-bold text-red-400 mt-2">
            {summary.pendingShoot}
          </h2>

        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">

          <p className="text-gray-400">
            Delivery Pending
          </p>

          <h2 className="text-3xl font-bold text-green-400 mt-2">
            {summary.pendingDelivery}
          </h2>

        </div>

      </div>

      {/* Search */}

      <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">

        <input
          type="text"
          placeholder="🔍 Search Client..."
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setPage(1);
          }}
          className="w-full p-3 rounded-lg bg-slate-800 border border-slate-700 text-white outline-none"
        />

      </div>
      <div className="flex flex-wrap gap-4 mt-5">

        <select
          value={eventFilter}
          onChange={(e) => {
             setEventFilter(e.target.value);
             setPage(1);
          }}
          className="bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white"
        >
          {eventTypes.map((type) => (
            <option key={type} value={type}>
              {type}
            </option>
          ))}
        </select>

        {[
          "All",
          "Pending Shoot",
          "Completed Shoot",
          "Editing",
          "Album",
          "Pending Delivery",
          "Delivered",
        ].map((item) => (
          <button
            key={item}
            onClick={() => {
              setFilter(item);
              setPage(1);
            }}
            className={`px-4 py-2 rounded-lg ${
              filter === item
                ? "bg-blue-600 text-white"
                : "bg-slate-800 text-gray-300"
            }`}
          >
            {item}
          </button>
        ))}

      </div>
      {/* Client Table */}

      <ClientTable
        clients={clients}
        loading={loading}
        onEdit={(client) => {
          setSelectedClient(client);
          setShowModal(true);
        }}
        onDelete={handleDelete}
      />
      <div className="flex justify-between items-center mt-6">

        <div className="flex items-center gap-2">

          <span className="text-gray-400">
            Rows
          </span>

          <select
            value={limit}
            onChange={(e) => {
              setLimit(Number(e.target.value));
              setPage(1);
            }}
            className="bg-slate-800 text-white border border-slate-700 rounded px-2 py-1"
          >
            <option value={10}>10</option>
            <option value={25}>25</option>
            <option value={50}>50</option>
          </select>

        </div>

        <div className="flex items-center gap-3">

          <button
            disabled={page === 1}
            onClick={() => setPage(page - 1)}
            className="bg-slate-800 text-white px-4 py-2 rounded disabled:opacity-40"
          >
            Previous
          </button>

          <span className="text-white">
            {page} / {totalPages}
          </span>

          <button
            disabled={page === totalPages}
            onClick={() => setPage(page + 1)}
            className="bg-slate-800 text-white px-4 py-2 rounded disabled:opacity-40"
          >
            Next
          </button>

        </div>

      </div>

      {/* Modal */}

      {showModal && (
        <AddClientModal
          client={selectedClient}
          onClose={() => {
            setShowModal(false);
            setSelectedClient(null);
          }}
          onSuccess={async () => {
            await fetchClients();

            setShowModal(false);
            setSelectedClient(null);

            if (location.search.includes("new=true")) {
              navigate("/dashboard");
            }
            
          }}
        />
      )}

    </Layout>
  );
}

export default Clients;