import { useEffect, useState } from "react";
import Layout from "../components/layout/Layout";
import API from "../services/api";
import toast from "react-hot-toast";

function Settings() {
  const [form, setForm] = useState({
    studioName: "",
    ownerName: "",
    phone: "",
    email: "",
    address: "",
    website: "",
    gstNumber: "",
    invoicePrefix: "",
    currency: "",
    galleryDownload: true,
    galleryWatermark: false,
    logo: "",
  });

  const [logo, setLogo] = useState(null);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const res = await API.get("/settings");
      setForm(res.data.studio);
    } catch (err) {
      console.log(err);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;

    setForm({
      ...form,
      [name]: type === "checkbox" ? checked : value,
    });
  };

  const uploadLogo = async () => {
    if (!logo) {
      return toast.error("Please select a logo");
    }

    try {
      setUploading(true);

      const formData = new FormData();
      formData.append("logo", logo);

      await API.put("/logo", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      toast.success("Logo Uploaded Successfully");

      loadSettings();

      setLogo(null);

    } catch (err) {
      console.log(err);
      toast.error("Logo Upload Failed");
    } finally {
      setUploading(false);
    }
  };

  const saveSettings = async (e) => {
    e.preventDefault();

    try {
      await API.put("/settings", form);

      toast.success("Settings Updated");
    } catch (err) {
      console.log(err);
      toast.error("Update Failed");
    }
  };

  return (
    <Layout>
      <div className="max-w-4xl mx-auto">

        <h1 className="text-3xl font-bold text-white mb-8">
          Studio Settings
        </h1>

        {/* Logo Upload */}

        <div className="bg-slate-900 p-8 rounded-xl mb-6">

          <h2 className="text-xl font-bold text-white mb-5">
            Studio Logo
          </h2>

          {form.logo ? (
            <img
              src={form.logo}
              alt="Studio Logo"
              className="w-40 h-40 object-contain bg-white rounded-lg p-3 mb-5"
            />
          ) : (
            <div className="w-40 h-40 rounded-lg bg-slate-800 flex justify-center items-center text-gray-400 mb-5">
              No Logo
            </div>
          )}

          <input
            type="file"
            accept="image/*"
            onChange={(e) => setLogo(e.target.files[0])}
            className="text-white block mb-4"
          />

          <button
            type="button"
            onClick={uploadLogo}
            disabled={uploading}
            className="bg-blue-600 hover:bg-blue-700 px-6 py-2 rounded-lg text-white"
          >
            {uploading ? "Uploading..." : "Upload Logo"}
          </button>

        </div>

        {/* Settings Form */}

        <form
          onSubmit={saveSettings}
          className="bg-slate-900 p-8 rounded-xl space-y-5"
        >

          <input
            name="studioName"
            value={form.studioName}
            onChange={handleChange}
            placeholder="Studio Name"
            className="w-full p-3 rounded bg-slate-800 text-white"
          />

          <input
            name="ownerName"
            value={form.ownerName}
            onChange={handleChange}
            placeholder="Owner Name"
            className="w-full p-3 rounded bg-slate-800 text-white"
          />

          <input
            name="phone"
            value={form.phone}
            onChange={handleChange}
            placeholder="Phone"
            className="w-full p-3 rounded bg-slate-800 text-white"
          />

          <input
            name="email"
            value={form.email}
            onChange={handleChange}
            placeholder="Email"
            className="w-full p-3 rounded bg-slate-800 text-white"
          />

          <input
            name="address"
            value={form.address}
            onChange={handleChange}
            placeholder="Address"
            className="w-full p-3 rounded bg-slate-800 text-white"
          />

          <input
            name="website"
            value={form.website}
            onChange={handleChange}
            placeholder="Website"
            className="w-full p-3 rounded bg-slate-800 text-white"
          />

          <input
            name="gstNumber"
            value={form.gstNumber}
            onChange={handleChange}
            placeholder="GST Number"
            className="w-full p-3 rounded bg-slate-800 text-white"
          />

          <div className="grid grid-cols-2 gap-5">

            <input
              name="invoicePrefix"
              value={form.invoicePrefix}
              onChange={handleChange}
              placeholder="Invoice Prefix"
              className="p-3 rounded bg-slate-800 text-white"
            />

            <input
              name="currency"
              value={form.currency}
              onChange={handleChange}
              placeholder="Currency"
              className="p-3 rounded bg-slate-800 text-white"
            />

          </div>

          <label className="flex items-center gap-3 text-white">
            <input
              type="checkbox"
              name="galleryDownload"
              checked={form.galleryDownload}
              onChange={handleChange}
            />
            Allow Gallery Download
          </label>

          <label className="flex items-center gap-3 text-white">
            <input
              type="checkbox"
              name="galleryWatermark"
              checked={form.galleryWatermark}
              onChange={handleChange}
            />
            Enable Watermark
          </label>

          <button
            type="submit"
            className="bg-green-600 hover:bg-green-700 px-6 py-3 rounded-lg text-white"
          >
            Save Settings
          </button>

        </form>

      </div>
    </Layout>
  );
}

export default Settings;