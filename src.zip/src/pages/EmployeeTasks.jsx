import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import EmployeeAPI from "../services/employeeApi";
import toast from "react-hot-toast";

function EmployeeTasks() {
  const navigate = useNavigate();

  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    try {
      const res = await EmployeeAPI.get("/task/employee");

      setTasks(res.data.tasks || []);

    } catch (err) {

      console.log(err);

      toast.error("Failed to load tasks");

    } finally {

      setLoading(false);

    }
  };

  const updateStatus = async (id, status) => {

    try {

      await EmployeeAPI.put(`/task/${id}/status`, {
        status,
      });

      toast.success("Task Updated");

      fetchTasks();

    } catch (err) {

      console.log(err);

      toast.error("Update Failed");

    }

  };
    if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center text-white text-2xl">
        Loading...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 p-8">

      <div className="flex justify-between items-center mb-8">

        <div>

          <h1 className="text-3xl font-bold text-white">
            My Tasks
          </h1>

          <p className="text-gray-400 mt-2">
            View and manage your assigned tasks
          </p>

        </div>

        <button
          onClick={() => navigate("/employee/dashboard")}
          className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg"
        >
          ← Dashboard
        </button>

      </div>

      {tasks.length === 0 ? (

        <div className="bg-slate-900 rounded-xl p-10 text-center">

          <h2 className="text-2xl text-gray-400">
            No Tasks Assigned
          </h2>

        </div>

      ) : (

        <div className="grid md:grid-cols-2 gap-6">

          {tasks.map((task) => (

            <div
              key={task._id}
              className="bg-slate-900 rounded-xl p-6 border border-slate-800"
            >

              <div className="flex justify-between items-start">

                <div>

                  <h2 className="text-2xl font-bold text-white">
                    {task.title}
                  </h2>

                  <p className="text-gray-400 mt-1">
                    {task.description}
                  </p>

                </div>

                <span
                  className={`px-3 py-1 rounded-full text-sm ${
                    task.priority === "High"
                      ? "bg-red-600 text-white"
                      : task.priority === "Medium"
                      ? "bg-yellow-600 text-white"
                      : "bg-green-600 text-white"
                  }`}
                >
                  {task.priority}
                </span>

              </div>

              <div className="mt-5 space-y-2">

                <p className="text-gray-300">
                  <b>Category:</b> {task.category}
                </p>

                {task.client && (

                  <>

                    <p className="text-gray-300">
                      <b>Client:</b> {task.client.clientName}
                    </p>

                    <p className="text-gray-300">
                      <b>Event:</b> {task.client.eventType}
                    </p>

                  </>

                )}

                <p className="text-gray-300">
                  <b>Due Date:</b>{" "}
                  {new Date(task.dueDate).toLocaleDateString()}
                </p>

                <div className="mt-3">
                  <span
                    className={`px-3 py-1 rounded-full ${
                      task.status === "Completed"
                        ? "bg-green-600 text-white"
                        : task.status === "In Progress"
                        ? "bg-yellow-600 text-white"
                        : "bg-blue-600 text-white"
                    }`}
                  >
                    {task.status}
                  </span>
                </div>

              </div>

              <div className="flex gap-3 mt-6">
                                {task.status === "Pending" && (
                  <button
                    onClick={() =>
                      updateStatus(task._id, "In Progress")
                    }
                    className="bg-yellow-600 hover:bg-yellow-700 text-white px-4 py-2 rounded-lg"
                  >
                    ▶ Start Task
                  </button>
                )}

                {task.status === "In Progress" && (
                  <button
                    onClick={() =>
                      updateStatus(task._id, "Completed")
                    }
                    className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg"
                  >
                    ✅ Complete Task
                  </button>
                )}

                {task.status === "Completed" && (
                  <button
                    disabled
                    className="bg-gray-700 text-gray-300 px-4 py-2 rounded-lg cursor-not-allowed"
                  >
                    ✔ Completed
                  </button>
                )}

              </div>

            </div>

          ))}

        </div>

      )}

    </div>
  );
}

export default EmployeeTasks;