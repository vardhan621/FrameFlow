import { useEffect, useState } from "react";
import { formatDistanceToNow } from "date-fns";
import { useParams } from "react-router-dom";
import Layout from "../components/layout/Layout";
import API from "../services/api";
import { useRef } from "react";
import {
  FiCopy,
  FiMessageCircle,
  FiDownload,
} from "react-icons/fi";
import { sendWhatsApp } from "../utils/whatsapp";
import { messages } from "../utils/messageTemplates";
import toast from "react-hot-toast";

function ClientDetails() {
  const { id } = useParams();

  const [client, setClient] = useState(null);
  const [payments, setPayments] = useState([]);
  const [paidAmount, setPaidAmount] = useState(0);
  const [employees, setEmployees] = useState([]);
  const [activities, setActivities] = useState([]);
  const [downloading, setDownloading] = useState(false);
  const folderInputRef = useRef(null);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [timeline, setTimeline] = useState([]);
  const [workflow, setWorkflow] = useState({
    shootStatus: "Pending",
    editingStatus: "Pending",
    albumStatus: "Pending",
    deliveryStatus: "Pending",

    photographer: "",
    videographer: "",
    assistant: "",
    droneOperator: "",

    location: "",
    shootTime: "",
    googleMapLink: "",
  });

  useEffect(() => {
    fetchClient();
    fetchEmployees();
    fetchActivities();
    fetchTimeline();
  }, []);

  const fetchEmployees = async () => {
    try {
      const res = await API.get("/employee");
      setEmployees(res.data.employees);
    } catch (error) {
      console.log(error);
    }
  };
  const fetchActivities = async () => {
    try {
      const res = await API.get(`/activity/${id}`);
      setActivities(res.data.activities);
    } catch (err) {
      console.log(err);
    }
  };
  const fetchTimeline = async () => {
    try {
      const res = await API.get(`/timeline/${id}`);
      setTimeline(res.data.timeline);
    } catch (err) {
      console.log(err);
    }
  };
  const fetchClient = async () => {
    try {
      const res = await API.get(`/client/${id}`);

      const data = res.data.client;

      setClient(data);
      setPayments(res.data.payments);
      setPaidAmount(res.data.paidAmount);

      setWorkflow({
        shootStatus: data.shootStatus || "Pending",
        editingStatus: data.editingStatus || "Pending",
        albumStatus: data.albumStatus || "Pending",
        deliveryStatus: data.deliveryStatus || "Pending",

        photographer: data.photographer || "",
        videographer: data.videographer || "",
        assistant: data.assistant || "",
        droneOperator: data.droneOperator || "",

        location: data.location || "",
        shootTime: data.shootTime || "",
        googleMapLink: data.googleMapLink || "",
      });

    } catch (error) {
      console.log(error);
    }
  };

  const updateWorkflow = async () => {
    try {

      const data = { ...workflow };

      if (
        data.shootStatus === "Completed" &&
        data.editingStatus === "Pending"
      ) {
        data.editingStatus = "In Progress";
      }

      await API.put(`/client/${client._id}`, data);

      toast.success("Updated Successfully");

      fetchClient();
      fetchActivities();
      fetchTimeline();

    } catch (error) {

      console.log(error);

      toast.error("Update Failed");

    }
  };
 const uploadFile = async (type, files) => {
    try {
      if (!files || files.length === 0) return;

      const formData = new FormData();

      if (type === "album") {

        formData.append("file", files[0]);

        setUploading(true);

        await API.post(
          `/client/upload-pdf/${client._id}`,
          formData,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },

            onUploadProgress: (progressEvent) => {
              const percent = Math.round(
                (progressEvent.loaded * 100) /
                  progressEvent.total
              );

              setUploadProgress(percent);
            },
          }
        );

        setUploading(false);
        setUploadProgress(0);

      } else {

        for (let i = 0; i < files.length; i++) {
          formData.append("files", files[i]);
        }

        setUploading(true);

        await API.post(
          `/client/upload/${client._id}/${type}`,
          formData,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
            onUploadProgress: (event) => {
              const percent = Math.round((event.loaded * 100) / event.total);
              setUploadProgress(percent);
            },
          }
        );


      }

      toast.success("Uploaded Successfully");
      fetchClient();
      fetchActivities();
      fetchTimeline();
    } catch (err) {
      console.log(err);
      toast.error("Upload Failed");
    } finally {
      setUploading(false);
      setUploadProgress(0);
    }
  };
  const deleteFile = async (type, index) => {
    try {

      await API.delete(
        `/client/upload/${client._id}/${type}/${index}`
      );

      toast.success("Deleted");
      fetchClient();
      fetchActivities();
      fetchTimeline();

    } catch (err) {

      console.log(err);

      toast.error("Delete Failed");

    }
  };
  const getDownloadUrl = (url) => {
    if (!url) return "";

    return url.replace(
      "/upload/",
      "/upload/fl_attachment/"
    );
  };
  const downloadAllPhotos = async () => {
    try {
      setDownloading(true);

      const token = localStorage.getItem("token");

      const response = await fetch(
        `${API.defaults.baseURL}/download/gallery/${client._id}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (!response.ok) {
        throw new Error("Download Failed");
      }

      const blob = await response.blob();

      const url = window.URL.createObjectURL(blob);

      const link = document.createElement("a");

      link.href = url;
      link.download = `${client.clientName}.zip`;

      document.body.appendChild(link);

      link.click();

      link.remove();

      window.URL.revokeObjectURL(url);

      toast.success("Download Started");

    } catch (err) {

      console.log(err);

      toast.error("Download Failed");

    } finally {

      setDownloading(false);

    }
  };
  if (!client) {
    return (
      <Layout>
        <h2 className="text-white text-2xl">
          Loading...
        </h2>
      </Layout>
    );
  }
const packageFeatures = {
  Basic: {
    photographer: true,
    videographer: false,
    droneOperator: false,
    assistant: false,
  },

  Gold: {
    photographer: true,
    videographer: true,
    droneOperator: false,
    assistant: true,
  },

  Premium: {
    photographer: true,
    videographer: true,
    droneOperator: true,
    assistant: true,
  },
};

const features =
  packageFeatures[client.packageName] || packageFeatures.Basic;
  return (
    <Layout>

      <h1 className="text-3xl font-bold text-white mb-6">
        Client Details
      </h1>

      {/* Client Info */}

      <div className="bg-slate-900 rounded-xl border border-slate-800 p-6 mb-6">

        <h2 className="text-2xl text-white font-bold mb-4">
          {client.clientName}
        </h2>

        <p className="text-gray-300">
        <strong>📞 Phone :</strong> {client.phone}
        </p>

        <p className="text-gray-300">
        <strong>📧 Email :</strong> {client.email || "-"}
        </p>

        <p className="text-gray-300">
        <strong>🎉 Event :</strong> {client.eventType}
        </p>

        <p className="text-gray-300">
        <strong>📅 Date :</strong>{" "}
        {new Date(client.eventDate).toLocaleDateString()}
        </p>

        <p className="text-gray-300">
        <strong>📦 Package :</strong> {client.packageName}
        </p>

        <p className="text-gray-300">
        <strong>📍 Address :</strong> {client.address || "-"}
        </p>
        <div className="flex gap-3 mt-5">

          <a
            href={`tel:${client.phone}`}
            className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg text-white"
          >
            📞 Call
          </a>

          <a
            href={`https://wa.me/91${client.phone}`}
            target="_blank"
            rel="noreferrer"
            className="bg-green-600 hover:bg-green-700 px-4 py-2 rounded-lg text-white"
          >
            💬 WhatsApp
          </a>

        </div>  
      </div>

      {/* Summary */}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">

        <div className="bg-blue-600 rounded-xl p-6 text-center">
          <h3 className="text-white text-lg">
            Total Package
          </h3>

          <h2 className="text-4xl font-bold text-white mt-3">
            ₹{client.totalAmount}
          </h2>
        </div>

        <div className="bg-green-600 rounded-xl p-6 text-center">
          <h3 className="text-white text-lg">
            Paid Amount
          </h3>

          <h2 className="text-4xl font-bold text-white mt-3">
            ₹{paidAmount}
          </h2>
        </div>

        <div className="bg-red-600 rounded-xl p-6 text-center">
          <h3 className="text-white text-lg">
            Pending Amount
          </h3>

          <h2 className="text-4xl font-bold text-white mt-3">
            ₹{client.pendingAmount}
          </h2>
        </div>

      </div>
      
    
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-6 mb-6">

          <h2 className="text-2xl text-white font-bold mb-5">
          Shoot Details
          </h2>

          <div className="grid md:grid-cols-2 gap-5">
            {features.photographer && (
            <div>

            <label className="text-gray-300">
            Photographer
            </label>

            <select
            value={workflow.photographer}
            onChange={(e)=>
            setWorkflow({
            ...workflow,
            photographer:e.target.value
            })
            }
            className="w-full mt-2 p-3 rounded-lg bg-slate-800 text-white"
            >

            <option value="">
            Select
            </option>

            {employees
            .filter(emp=>emp.role==="Photographer")
            .map(emp=>(
            <option
            key={emp._id}
            value={emp.name}
            >
            {emp.name}
            </option>
            ))}

            </select>

            </div>
            )}

          {features.videographer && (
          <div>

            <label className="text-gray-300">
              Videographer
            </label>

            <select
              value={workflow.videographer}
              onChange={(e)=>
                setWorkflow({
                  ...workflow,
                  videographer:e.target.value
                })
              }
              className="w-full mt-2 p-3 rounded-lg bg-slate-800 text-white"
            >

              <option value="">Select</option>

              {employees
                .filter(emp=>emp.role==="Videographer")
                .map(emp=>(
                  <option key={emp._id} value={emp.name}>
                    {emp.name}
                  </option>
                ))
              }

            </select>

          </div>
          )}

         {features.assistant && (
          <div>

            <label className="text-gray-300">
              Assistant
            </label>

            <select
              value={workflow.assistant}
              onChange={(e)=>
                setWorkflow({
                  ...workflow,
                  assistant:e.target.value
                })
              }
              className="w-full mt-2 p-3 rounded-lg bg-slate-800 text-white"
            >

              <option value="">
                Select Assistant
              </option>

              {employees
                .filter(emp=>emp.role==="Assistant")
                .map(emp=>(
                  <option key={emp._id} value={emp.name}>
                    {emp.name}
                  </option>
                ))
              }

            </select>

          </div>
          )}

          {features.droneOperator && (
          <div>

            <label className="text-gray-300">
              Drone Operator
            </label>

            <select
              value={workflow.droneOperator}
              onChange={(e)=>
                setWorkflow({
                  ...workflow,
                  droneOperator:e.target.value
                })
              }
              className="w-full mt-2 p-3 rounded-lg bg-slate-800 text-white"
            >

              <option value="">
                Select Drone Operator
              </option>

              {employees
                .filter(emp=>emp.role==="Drone Operator")
                .map(emp=>(
                  <option key={emp._id} value={emp.name}>
                    {emp.name}
                  </option>
                ))
              }

            </select>

          </div>
          )}          <div>

          <label className="text-gray-300">
          Venue
          </label>

          <input
          value={workflow.location || ""}
          onChange={(e)=>
          setWorkflow({
          ...workflow,
          location:e.target.value
          })
          }
          className="w-full mt-2 p-3 rounded-lg bg-slate-800 text-white"
          />

          </div>

          <div>

          <label className="text-gray-300">
          Shoot Time
          </label>

          <input
          type="time"
          value={workflow.shootTime || ""}
          onChange={(e)=>
          setWorkflow({
          ...workflow,
          shootTime:e.target.value
          })
          }
          className="w-full mt-2 p-3 rounded-lg bg-slate-800 text-white"
          />

          </div>

          <div className="md:col-span-2">

          <label className="text-gray-300">
          Google Maps Link
          </label>

          <input
            placeholder="https://maps.google.com/..."
            value={workflow.googleMapLink}
            onChange={(e)=>
            setWorkflow({
            ...workflow,
            googleMapLink:e.target.value
            })
            }
            className="w-full mt-2 p-3 rounded-lg bg-slate-800 text-white"
          />

          {workflow.googleMapLink && (
          <a
          href={workflow.googleMapLink}
          target="_blank"
          rel="noreferrer"
          className="inline-block mt-3 bg-green-600 hover:bg-green-700 px-4 py-2 rounded-lg text-white"
          >
          📍 Open Google Maps
          </a>
          )}

          </div>

          </div>


          </div>
           <div className="bg-slate-900 rounded-xl border border-slate-800 p-6 mb-6">

        <h2 className="text-2xl font-bold text-white mb-5">
            Workflow Status
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">

            <div>
            <label className="text-gray-300">Shoot</label>
            <select
                className="w-full mt-2 p-3 rounded-lg bg-slate-800 text-white"
                value={workflow.shootStatus}
                onChange={(e) =>
                setWorkflow({
                    ...workflow,
                    shootStatus: e.target.value,
                })
                }
            >
                <option value="Pending">🟡 Pending</option>
                <option value="In Progress">🟠 In Progress</option>
                <option value="Completed">🟢 Completed</option>
                <option value="Cancelled">🔴 Cancelled</option>
            </select>
            </div>

            <div>
            <label className="text-gray-300">Editing</label>
            <select
                className="w-full mt-2 p-3 rounded-lg bg-slate-800 text-white"
                value={workflow.editingStatus}
                onChange={(e) =>
                setWorkflow({
                    ...workflow,
                    editingStatus: e.target.value,
                })
                }
            >
                <option value="Pending">Pending</option>
                <option value="In Progress">In Progress</option>
                <option value="Completed">Completed</option>
            </select>
            </div>

            <div>
            <label className="text-gray-300">Album</label>
            <select
                className="w-full mt-2 p-3 rounded-lg bg-slate-800 text-white"
                value={workflow.albumStatus}
                onChange={(e) =>
                setWorkflow({
                    ...workflow,
                    albumStatus: e.target.value,
                })
                }
            >
                <option value="Pending">Pending</option>
                <option value="Designing">Designing</option>
                <option value="Printing">Printing</option>
                <option value="Ready">Ready</option>
            </select>
            </div>

            <div>
            <label className="text-gray-300">Delivery</label>
            <select
                className="w-full mt-2 p-3 rounded-lg bg-slate-800 text-white"
                value={workflow.deliveryStatus}
                onChange={(e) =>
                setWorkflow({
                    ...workflow,
                    deliveryStatus: e.target.value,
                })
                }
            >
                <option value="Pending">Pending</option>
                <option value="Delivered">Delivered</option>
            </select>
            </div>

        </div>

        <button
            onClick={updateWorkflow}
            className="mt-6 bg-blue-600 hover:bg-blue-700 px-6 py-2 rounded-lg text-white"
        >
            💾 Save All Changes
        </button>

        </div>
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-6 mb-6">

          <h2 className="text-2xl font-bold text-white mb-6">
            Gallery Settings
          </h2>

          <div className="grid md:grid-cols-2 gap-6">

            <div className="flex items-center justify-between">

              <span className="text-white">
                Gallery Enabled
              </span>

              <input
                type="checkbox"
                checked={client.galleryEnabled}
                onChange={(e)=>
                  setClient({
                    ...client,
                    galleryEnabled:e.target.checked
                  })
                }
                className="w-5 h-5"
              />

            </div>

            <div className="flex items-center justify-between">

              <span className="text-white">
                Allow Download
              </span>

              <input
                type="checkbox"
                checked={client.allowDownload}
                onChange={(e)=>
                  setClient({
                    ...client,
                    allowDownload:e.target.checked
                  })
                }
                className="w-5 h-5"
              />

            </div>

            <div>

              <label className="text-gray-300">
                Gallery Expiry
              </label>

              <input
                type="date"
                value={
                  client.galleryExpiry
                    ? client.galleryExpiry.substring(0,10)
                    : ""
                }
                onChange={(e)=>
                  setClient({
                    ...client,
                    galleryExpiry:e.target.value
                  })
                }
                className="w-full mt-2 p-3 rounded-lg bg-slate-800 text-white"
              />

            </div>

          </div>

          <button
            onClick={async()=>{

              try{

                await API.put(`/client/${client._id}`,{

                  galleryEnabled:client.galleryEnabled,

                  allowDownload:client.allowDownload,

                  galleryExpiry:client.galleryExpiry,

                });

                toast.success("Gallery Settings Updated");

              }catch(err){

                console.log(err);

                toast.error("Update Failed");

              }

            }}
            className="mt-6 bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg"
          >
            Save Gallery Settings
          </button>

        </div>
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-6 mb-6">

  <h2 className="text-2xl text-white font-bold mb-6">
    Upload Files
  </h2>

  <div className="grid md:grid-cols-2 gap-5">

    <div>
      <label className="text-white">
        📷 Raw Photos
      </label>

      <input
        type="file"
        multiple
        accept="image/*"
        onChange={(e)=>
          uploadFile("raw-photo", e.target.files)
        }
      />
    </div>

    <div>
      <label className="text-white">
        🎥 Raw Videos
      </label>

      <input
        type="file"
        multiple
        accept="video/*"
        onChange={(e)=>
          uploadFile("raw-video", e.target.files)
        }
      />
    </div>

    <div>
      <label className="text-white">
        🖼 Edited Photos
      </label>

      <input
        type="file"
        multiple
        accept="image/*"
        onChange={(e)=>
          uploadFile("edited-photo", e.target.files)
        }
      />
    </div>

    <div>
      <label className="text-white">
        🎬 Final Video
      </label>

      <input
        type="file"
        multiple
        accept="video/*"
        onChange={(e)=>
          uploadFile("final-video", e.target.files)
        }
      />
    </div>

    <div className="md:col-span-2">

      <label className="text-white">
        📄 Album PDF
      </label>

      <input
        type="file"
        accept=".pdf"
        onChange={(e)=>
          uploadFile("album", e.target.files)
        }
        className="mt-2 text-white"
      />

    </div>
    <div className="md:col-span-2 mt-5">

      <input
        ref={folderInputRef}
        type="file"
        multiple
        hidden
        webkitdirectory=""
        directory=""
        onChange={(e) =>
          uploadFile("raw-photo", e.target.files)
        }
      />

      <button
        onClick={() => folderInputRef.current.click()}
        className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-3 rounded-lg"
      >
        📂 Upload Photo Folder
      </button>

    </div>
    {uploading && (
      <div className="mt-6">

        <div className="w-full h-3 bg-slate-700 rounded-full">

          <div
            className="h-3 bg-green-500 rounded-full transition-all"
            style={{
              width: `${uploadProgress}%`,
            }}
          />

        </div>

        <p className="text-white mt-2">
          Uploading... {uploadProgress}%
        </p>

      </div>
    )}

  </div>

</div>
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-6 mb-6">

        <h2 className="text-2xl text-white font-bold mb-5">
          📷 Raw Photos ({client.rawPhotos?.length || 0})
        </h2>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {client.rawPhotos?.length === 0 && (
            <p className="text-gray-400 text-center py-8">
              No Raw Photos Uploaded
            </p>
          )}
          {client.rawPhotos?.map((photo, index) => (

          <div
            key={index}
            className="bg-slate-800 rounded-lg overflow-hidden"
          >

            <img
              src={photo.url}
              alt=""
              className="h-40 w-full object-cover"
            />

            <p className="text-gray-400 text-xs px-3 pt-2">
              Uploaded :
              {new Date(photo.uploadedAt).toLocaleString()}
            </p>

            <div className="flex gap-2 p-3">

              <a
                href={photo.url}
                target="_blank"
                rel="noreferrer"
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-center py-2 rounded text-white"
              >
                👁 View
              </a>

              <a
                href={getDownloadUrl(photo.url)}
                target="_blank"
                rel="noreferrer"
                className="flex-1 bg-green-600 hover:bg-green-700 text-center py-2 rounded text-white"
              >
                ⬇ Download
              </a>

              <button
                onClick={() => {
                  if (window.confirm("Delete this photo?")) {
                    deleteFile("raw-photo", index);
                  }
                }}
                className="bg-red-600 hover:bg-red-700 px-3 rounded text-white"
                >
                🗑
              </button>

            </div>

          </div>

        ))}
          

        </div>

      </div>
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-6 mb-6">

        <h2 className="text-2xl text-white font-bold mb-5">
        🎥 Raw Videos ({client.rawVideos?.length || 0})
        </h2>

        <div className="grid md:grid-cols-2 gap-5">
        {client.rawVideos?.length === 0 && (
          <p className="text-gray-400 text-center py-8">
            No Raw Videos Uploaded
          </p>
        )}
        {client.rawVideos?.map((video, index) => (

          <div
            key={index}
            className="bg-slate-800 rounded-lg p-3"
          >

            <video
              src={video.url}
              controls
              className="rounded-lg w-full"
            />
            <p className="text-gray-400 text-xs mt-2">
              Uploaded :
              {new Date(video.uploadedAt).toLocaleString()}
            </p>

            <div className="flex gap-2 mt-3">

              <a
                href={video.url}
                target="_blank"
                rel="noreferrer"
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-center py-2 rounded text-white"
              >
                👁 View
              </a>

              <a
                href={getDownloadUrl(video.url)}
                target="_blank"
                rel="noreferrer"
                className="flex-1 bg-green-600 hover:bg-green-700 text-center py-2 rounded text-white"
              >
                ⬇ Download
              </a>

              <button
                onClick={() => {
                  if (window.confirm("Delete this video?")) {
                    deleteFile("raw-video", index);
                  }
                }}
                className="bg-red-600 hover:bg-red-700 px-3 rounded text-white"
              >
                🗑
              </button>

            </div>

          </div>

        ))}

        </div>

      </div>
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-6 mb-6">

        <h2 className="text-2xl text-white font-bold mb-5">
        🖼 Edited Photos ({client.editedPhotos?.length || 0})
        </h2>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {client.editedPhotos?.length === 0 && (
          <p className="text-gray-400 text-center py-8">
            No Edited Photos Uploaded
          </p>
        )}
        {client.editedPhotos?.map((photo, index) => (

          <div
            key={index}
            className="bg-slate-800 rounded-lg overflow-hidden"
          >

            <img
              src={photo.url}
              alt=""
              className="h-40 w-full object-cover"
            />
            <p className="text-gray-400 text-xs px-3 pt-2">
              Uploaded :
              {new Date(photo.uploadedAt).toLocaleString()}
            </p>
            <div className="flex gap-2 p-3">

              <a
                href={photo.url}
                target="_blank"
                rel="noreferrer"
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-center py-2 rounded text-white"
              >
                👁 View
              </a>

              <a
                href={getDownloadUrl(photo.url)}
                target="_blank"
                rel="noreferrer"
                className="flex-1 bg-green-600 hover:bg-green-700 text-center py-2 rounded text-white"
              >
                ⬇ Download
              </a>

              <button
                onClick={() => {
                  if (window.confirm("Delete this photo?")) {
                    deleteFile("edited-photo", index);
                  }
                }}
                className="bg-red-600 hover:bg-red-700 px-3 rounded text-white"
              >
                🗑
              </button>

            </div>

          </div>

        ))}

        </div>

      </div>
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-6 mb-6">

        <h2 className="text-2xl text-white font-bold mb-5">
        🎬 Final Videos ({client.finalVideos?.length || 0})
        </h2>

        <div className="grid md:grid-cols-2 gap-5">
        {client.finalVideos?.length === 0 && (
          <p className="text-gray-400 text-center py-8">
            No Final Videos Uploaded
          </p>
        )}
        {client.finalVideos?.map((video, index) => (

          <div
            key={index}
            className="bg-slate-800 rounded-lg p-3"
          >

            <video
              src={video.url}
              controls
              className="rounded-lg w-full"
            />
            <p className="text-gray-400 text-xs mt-2">
              Uploaded :
              {new Date(video.uploadedAt).toLocaleString()}
            </p>
            <div className="flex gap-2 mt-3">

              <a
                href={video.url}
                target="_blank"
                rel="noreferrer"
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-center py-2 rounded text-white"
              >
                👁 View
              </a>

              <a
                href={getDownloadUrl(video.url)}
                target="_blank"
                rel="noreferrer"
                className="flex-1 bg-green-600 hover:bg-green-700 text-center py-2 rounded text-white"
              >
                ⬇ Download
              </a>

              <button
                onClick={() => {
                  if (window.confirm("Delete this video?")) {
                    deleteFile("final-video", index);
                  }
                }}
                className="bg-red-600 hover:bg-red-700 px-3 rounded text-white"
              >
                🗑
              </button>

            </div>

          </div>

        ))}

        </div>

      </div>
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-6 mb-6">

        <h2 className="text-2xl text-white font-bold mb-5">
        📄 Album PDF
        </h2>

       {client.albumPdf ? (

        <div className="flex gap-3">

          <a
            href={`https://docs.google.com/gview?embedded=true&url=${encodeURIComponent(client.albumPdf.url)}`}
            target="_blank"
            rel="noreferrer"
            className="bg-blue-600 hover:bg-blue-700 px-5 py-3 rounded-lg text-white"
          >
            👁 Open PDF
          </a>

          <a
            href={`${client.albumPdf.url}?fl_attachment`}
            target="_blank"
            rel="noreferrer"
            className="bg-green-600 hover:bg-green-700 px-5 py-3 rounded-lg text-white"
          >
            ⬇ Download
          </a>

          <button
            onClick={()=>{
              if(window.confirm("Delete Album PDF?")){
                deleteFile("album",0);
              }
            }}
            className="bg-red-600 hover:bg-red-700 px-5 py-3 rounded-lg text-white"
          >
            🗑 Delete
          </button>

        </div>

        ) : (

        <p className="text-gray-400">
        No Album Uploaded
        </p>

        )}

      </div>
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-6 mb-6">

        <h2 className="text-2xl font-bold text-white mb-6">
        Project Timeline
        </h2>

        {timeline.length===0 ? (

        <p className="text-gray-400">
        No Timeline Yet
        </p>

        ) : (

        <div className="space-y-5">

        {timeline.map(item=>(

        <div
        key={item._id}
        className="flex gap-4"
        >

        <div className="flex flex-col items-center">

        <div className="w-4 h-4 rounded-full bg-green-500"></div>

        <div className="w-1 flex-1 bg-slate-700"></div>

        </div>

        <div className="flex-1 bg-slate-800 rounded-xl p-4">

        <div className="flex justify-between">

        <h3 className="text-white font-semibold">
        {item.title}
        </h3>

        <span className="text-xs text-gray-500">
        {new Date(item.createdAt).toLocaleDateString()}
        </span>

        </div>

        <p className="text-gray-400 mt-2">
        {item.message}
        </p>

        <p className="text-xs text-blue-400 mt-3">
        {formatDistanceToNow(new Date(item.createdAt),{
        addSuffix:true
        })}
        </p>

        </div>

        </div>

        ))}

        </div>

        )}

        </div>
      <div className="flex flex-wrap gap-3 my-6">

        <button
          onClick={async () => {
          try {
            const token = localStorage.getItem("token");

            const res = await fetch(
              `${API.defaults.baseURL}/invoice/${client._id}`,
              {
                headers: {
                  Authorization: `Bearer ${token}`,
                },
              }
            );

            if (!res.ok) {
              throw new Error("Failed to generate invoice");
            }

            const blob = await res.blob();

            const url = window.URL.createObjectURL(blob);

            window.open(url, "_blank");

          } catch (err) {
            console.log(err);
            alert("Failed to generate invoice");
          }
        }}
          className="bg-purple-600 hover:bg-purple-700 text-white px-5 py-3 rounded-lg flex items-center gap-2"
        >
          📄 Generate Invoice
        </button>

        <button
          disabled={downloading}
          onClick={downloadAllPhotos}
          className="bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white px-5 py-3 rounded-lg flex items-center gap-2"
        >
          <FiDownload />

          {downloading
            ? "Preparing ZIP..."
            : "Download All Photos"}

        </button>

        <button
          onClick={() => {
            if (!client.galleryEnabled) {
              return toast.error("Gallery is disabled");
            }

            const link =
            `${window.location.origin}/gallery/${client.galleryToken}`;

            navigator.clipboard.writeText(link);

            toast.success("Gallery Link Copied");
           
          }}
          className="bg-green-600 hover:bg-green-700 text-white px-5 py-3 rounded-lg flex items-center gap-2"
        >
          <FiCopy />
          Copy Gallery Link
        </button>
        <button
          onClick={() => sendWhatsApp(client.phone, messages.booking(client))}
          className="bg-green-600 hover:bg-green-700 text-white px-5 py-3 rounded-lg flex items-center gap-2"
        >
          <FiMessageCircle />
          Booking
        </button>
        <button
          onClick={() => sendWhatsApp(client.phone, messages.payment(client))}
          className="bg-yellow-600 hover:bg-yellow-700 text-white px-5 py-3 rounded-lg flex items-center gap-2"
        >
          <FiMessageCircle />
          Payment
        </button>
        <button
          onClick={() => sendWhatsApp(client.phone, messages.gallery(client))}
          className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-3 rounded-lg flex items-center gap-2"
        >
          <FiMessageCircle />
          Gallery
        </button>
        <button
          onClick={() => sendWhatsApp(client.phone, messages.album(client))}
          className="bg-pink-600 hover:bg-pink-700 text-white px-5 py-3 rounded-lg flex items-center gap-2"
        >
          <FiMessageCircle />
          Album
        </button>
        <button
          onClick={() => sendWhatsApp(client.phone, messages.delivery(client))}
          className="bg-purple-600 hover:bg-purple-700 text-white px-5 py-3 rounded-lg flex items-center gap-2"
        >
          <FiMessageCircle />
          Delivery
        </button>

      </div>
     
      {/* Payment History */}

      <div className="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden">

        <h2 className="text-2xl font-bold text-white p-5">
          Payment History
        </h2>

        <table className="w-full">

          <thead className="bg-slate-800">

            <tr>

              <th className="p-4 text-left text-gray-300">
                Date
              </th>

              <th className="p-4 text-left text-gray-300">
                Amount
              </th>

              <th className="p-4 text-left text-gray-300">
                Method
              </th>

              <th className="p-4 text-left text-gray-300">
                Notes
              </th>

            </tr>

          </thead>

          <tbody>

            {payments.length === 0 ? (

            <tr>

            <td
            colSpan="4"
            className="text-center text-gray-400 p-6"
            >

            No Payments Found

            </td>

            </tr>

            ) : (

            payments.map((payment)=>(

            <tr
            key={payment._id}
            className="border-t border-slate-800"
            >

            <td className="p-4 text-white">
            {new Date(payment.paymentDate).toLocaleDateString()}
            </td>

            <td className="p-4 text-green-400">
            ₹{payment.amount}
            </td>

            <td className="p-4 text-gray-300">
            {payment.paymentMethod}
            </td>

            <td className="p-4 text-gray-300">
            {payment.notes}
            </td>

            </tr>

            ))

            )}

            </tbody>

        </table>

      </div>

    </Layout>
  );
}

export default ClientDetails;