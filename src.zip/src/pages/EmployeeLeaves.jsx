import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import EmployeeAPI from "../services/employeeApi";
import toast from "react-hot-toast";

function EmployeeLeaves() {

  const navigate = useNavigate();

  const [leaves, setLeaves] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchLeaves();
  }, []);

  const fetchLeaves = async () => {
    try {

      const res = await EmployeeAPI.get("/leave/employee");

      setLeaves(res.data.leaves || []);

    } catch (err) {

      console.log(err);

      toast.error("Failed to load leaves");

    } finally {

      setLoading(false);

    }
  };

  return (
    <div className="min-h-screen bg-slate-950 p-8">

      <div className="flex justify-between items-center mb-8">

        <h1 className="text-3xl font-bold text-white">
          My Leave History
        </h1>

        <button
          onClick={() => navigate("/employee/dashboard")}
          className="bg-blue-600 hover:bg-blue-700 px-5 py-2 rounded-lg text-white"
        >
          Back
        </button>

      </div>

      <div className="bg-slate-900 rounded-xl overflow-hidden">

        <table className="w-full">

          <thead className="bg-slate-800">

            <tr>

              <th className="p-4 text-white">Date</th>

              <th className="p-4 text-white">Type</th>

              <th className="p-4 text-white">Reason</th>

              <th className="p-4 text-white">Status</th>

            </tr>

          </thead>

          <tbody>

            {loading ? (

              <tr>

                <td
                  colSpan="4"
                  className="text-center p-10 text-gray-400"
                >
                  Loading...
                </td>

              </tr>

            ) : leaves.length === 0 ? (

              <tr>

                <td
                  colSpan="4"
                  className="text-center p-10 text-gray-400"
                >
                  No Leave Requests
                </td>

              </tr>

            ) : (

              leaves.map((leave) => (

                <tr
                  key={leave._id}
                  className="border-t border-slate-800"
                >

                  <td className="p-4 text-center text-white">
                    {new Date(
                      leave.date
                    ).toLocaleDateString()}
                  </td>

                  <td className="p-4 text-center text-cyan-400">
                    {leave.leaveType}
                  </td>

                  <td className="p-4 text-center text-gray-300">
                    {leave.reason}
                  </td>

                  <td className="p-4 text-center">

                    <span
                      className={`px-3 py-1 rounded-full ${
                        leave.status === "Approved"
                          ? "bg-green-600/20 text-green-400"
                          : leave.status === "Rejected"
                          ? "bg-red-600/20 text-red-400"
                          : "bg-yellow-600/20 text-yellow-400"
                      }`}
                    >
                      {leave.status}
                    </span>

                  </td>

                </tr>

              ))

            )}

          </tbody>

        </table>

      </div>

    </div>
  );
}

export default EmployeeLeaves;